﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;

namespace DemoApp.View
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            SelectedValue.Text = "0";
            MandatoryOptionalColumnsList();
        }
        private bool dragStarted = false;

        private void Slider_DragCompleted(object sender, DragCompletedEventArgs e)
        {
            DoWork(((Slider)sender).Value);
            this.dragStarted = false;
        }

        private void Slider_DragStarted(object sender, DragStartedEventArgs e)
        {
            this.dragStarted = true;
        }

        private void Slider_ValueChanged(
            object sender,
            RoutedPropertyChangedEventArgs<double> e)
        {
            if (!dragStarted)
                DoWork(e.NewValue);
        }

        protected void DoWork(double value)
        {
            if (SelectedValue != null)
                SelectedValue.Text = Convert.ToUInt32(value).ToString();
        }

      
        private void Enable_Click(object sender, RoutedEventArgs e)
        {
            if (Enable.Content.ToString() == "Enable")
            {
                SelectedValue.IsEnabled = false;
                SliderValue.IsEnabled = false;
                Enable.Content = "Disable";
            }
            else if (Enable.Content.ToString() == "Disable")
            {
                SelectedValue.IsEnabled = true;
                SliderValue.IsEnabled = true;
                Enable.Content = "Enable";
            }

        }
        public void MandatoryOptionalColumnsList()
        {
            List<ScaleColumn> MColumnsList = new List<ScaleColumn>();
            for (int index = 100; index >= 10; index = index - 10)
            {
                MColumnsList.Add(new ScaleColumn() { Symbol = "-" });
                MColumnsList.Add(new ScaleColumn() { MColumnName = index.ToString() });
            }
            MColumnsListXaml.ItemsSource = MColumnsList;
            
        }
    }

    public class ScaleColumn
    {
        public string Symbol { get; set; }
        public string MColumnName { get; set; }
       
    }

}
