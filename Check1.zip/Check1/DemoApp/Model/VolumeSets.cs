﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoApp.Model
{
    public class VolumeSets
    {
        public List<int> Volumes;
        public VolumeSets()
        {
            Volumes = new List<int>();
            for (int index = 0; index < 100; index = index + 10)
                Volumes.Add(index);

        }
    }
}
